from flask import Flask, request, jsonify
import pandas as pd
import numpy as np
import joblib
from flask_cors import CORS

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=True)

MODEL_PATH = 'prophet_improved_model.pkl'

# Load model at startup
prophet_model = joblib.load(MODEL_PATH)

# List your regressors here (must match what model expects)
selected_regressors = [
    "Population by 1-year age groups and sex",
    "Life expectancy E(x) - complete",
    "Urban population growth (annual %)"
]

# Default/forecasted regressor values for each year
regressor_defaults = {
    2025: {"Population by 1-year age groups and sex": 1000000, "Life expectancy E(x) - complete": 65.2, "Urban population growth (annual %)": 3.1},
    2026: {"Population by 1-year age groups and sex": 1010000, "Life expectancy E(x) - complete": 65.5, "Urban population growth (annual %)": 3.0},
    2027: {"Population by 1-year age groups and sex": 1020000, "Life expectancy E(x) - complete": 65.7, "Urban population growth (annual %)": 2.9},
    # Add more years as needed
}

# Scaler parameters (from training)
scaler_means = [98575.0927, 23.7096965, 4.95195872]
scaler_stds = [37408.1211, 1.62889695, 0.193035471]
scaler_feature_order = [
    "Population by 1-year age groups and sex",
    "Life expectancy E(x) - complete",
    "Urban population growth (annual %)"
]

def scale_regressors(df):
    # Only scale the regressor columns
    for i, col in enumerate(scaler_feature_order):
        if col in df.columns:
            df[col] = (df[col] - scaler_means[i]) / scaler_stds[i]
    return df

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    file = request.files['file']
    df = pd.read_csv(file)
    df['ds'] = pd.to_datetime(df['ds'])

    # Scale regressors
    df = scale_regressors(df)

    # Make predictions
    forecast = prophet_model.predict(df)
    result = df[['ds']].copy()
    result['yhat'] = np.exp(forecast['yhat'])  # Inverse log if you trained on log
    result['yhat_lower'] = np.exp(forecast['yhat_lower'])
    result['yhat_upper'] = np.exp(forecast['yhat_upper'])
    # Convert 'ds' to ISO date string
    result['ds'] = result['ds'].dt.strftime('%Y-%m-%d')
    return result.to_json(orient='records')

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'healthy', 'message': 'Prophet prediction API is running'})

@app.route('/predict_years', methods=['POST'])
def predict_years():
    data = request.get_json()
    years = data.get('years', [])
    rows = []
    for year in years:
        reg_vals = regressor_defaults.get(year)
        if reg_vals is None:
            return jsonify({'error': f'Regressor values not found for year {year}'}), 400
        row = {'ds': f'{year}-01-01'}
        row.update(reg_vals)
        rows.append(row)
    df = pd.DataFrame(rows)
    df['ds'] = pd.to_datetime(df['ds'])

    # Do NOT scale regressors here
    df['ds'] = df['ds'].dt.strftime('%Y-%m-%d')
    return df.to_json(orient='records')

@app.route('/predict_population', methods=['POST', 'OPTIONS'])
def predict_population():
    if request.method == 'OPTIONS':
        return '', 200
    data = request.get_json()
    print("Received data:", data)
    df = pd.DataFrame(data)
    print("DataFrame columns:", df.columns)
    df['ds'] = pd.to_datetime(df['ds'])
    df = scale_regressors(df)
    forecast = prophet_model.predict(df)
    result = df[['ds']].copy()
    result['yhat'] = np.exp(forecast['yhat'])
    result['yhat_lower'] = np.exp(forecast['yhat_lower'])
    result['yhat_upper'] = np.exp(forecast['yhat_upper'])
    result['ds'] = result['ds'].dt.strftime('%Y-%m-%d')
    return result.to_json(orient='records')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True) 